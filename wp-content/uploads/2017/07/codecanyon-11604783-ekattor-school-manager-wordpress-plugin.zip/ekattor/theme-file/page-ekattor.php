<?php
/**
 * Template Name: Ekattor School Manager Frontend
 */

 echo do_shortcode( '[ekattor_school_manager]' );