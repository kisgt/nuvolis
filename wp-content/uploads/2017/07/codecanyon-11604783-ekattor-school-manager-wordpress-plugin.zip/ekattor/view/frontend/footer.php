<!-- Footer -->
        <hr>
        <div class="container" style="padding:10px 0px 30px;">
            <footer>

                <div style="text-align:center;">
                    &copy; 2015
                    <a href="http://creativeitem.com" target="_blank">Creativeitem</a>,
                    All rights reserved.
                </div>


            </footer>
        </div>

    </body>
</html>

