<!DOCTYPE html>
<html lang="en" dir="">
  <?php include 'css.php'; ?>
    <body class="page-body" >

        <div class="page-container horizontal-menu" id="main">

            <!-- HEADER -->    
            <header class="navbar" style="text-align:center; padding:10px 0px; ">
                <img src="<?php echo get_logo_url(); ?>" height="48" alt="" />

                <h3 style="color:#fff; font-weight:100;"> Ekattor School Manager Wordpress Plugin</h3>
            </header>
