	<footer class="main">
	    &copy; 2015 <strong><a href="http://www.creativeitem.com/" target="_blank">Creativeitem</a></strong> 
	</footer>
</div>